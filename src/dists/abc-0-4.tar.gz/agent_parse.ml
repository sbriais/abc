exception Found of string

(* table des symboles *)
class parse_helper =
object(self)
  val vars = Hashtbl.create 10
  val agents = Hashtbl.create 10
  val mutable context = []
  val mutable counter = Name.zero
  method private new_var = 
    counter <- Name.succ counter
  method reset =
    Hashtbl.clear vars;
    counter <- Name.zero;
    Hashtbl.clear agents;
    context <- []
  method get (s:string) =
    (try
       Hashtbl.find vars s
     with
	 Not_found ->
	   self#new_var;
	   Hashtbl.add vars s counter;
	   counter)
  method reverse (n:Name.t) =
    (try
       Hashtbl.iter 
	 (fun s m -> if (Name.compare n m = 0) then raise (Found(s)))
	 vars;
       None
     with
	 Found(s) -> Some(s))
  method push (x:Name.t) =
    context <- x::context
  method pop n =
    (try
       for i = 1 to n do
	 context <- List.tl context;
       done;
     with _ -> ());
    Hashtbl.iter (fun s k -> if !k >= n then k := (!k) - n else k := 0) agents;
  method define (s:string) =
    Hashtbl.add agents s (ref (List.length context))
  method get_context (s:string) =
    (try
       let k = !(Hashtbl.find agents s) in
       let rec get_n n = function
	   [] -> []
	 | x::xs -> if n <= 0 then [] else x::(get_n (n-1) xs)
       in
	 get_n k (List.rev context)
     with Not_found -> List.rev context)
  method get_current_context = List.rev context
end

let helper = new parse_helper
