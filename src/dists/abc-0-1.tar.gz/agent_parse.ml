(* table des symboles *)
let (vars:(string,Name.t) Hashtbl.t) = Hashtbl.create 10

let counter = ref Name.zero;;

let new_var () = 
  let c = !counter in counter := Name.succ c;c
;;

let reinit () = 
  Hashtbl.clear vars;
  counter := Name.zero
;;

let get s =
  (try
     Hashtbl.find vars s
   with
       Not_found ->
	 let n = new_var () in Hashtbl.add vars s n;n)
;;

