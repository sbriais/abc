type command = 
    Def of string * Agent.agent
  | Eqd of Name.t list * Agent.agent * Agent.agent
  | Weqd of Name.t list * Agent.agent * Agent.agent
  | Show of Agent.agent
  | Print of Agent.agent
  | Latex of Agent.agent
  | Exit
  | Reset
  | Help
  | Step of Agent.agent
  | Rate of int
  | Maxrate of int
  | Load of string
